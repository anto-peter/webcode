﻿Set-Location C:\Lab\dockerbuild
Get-ChildItem

docker images

Invoke-Item .\web

code .\web\Dockerfile

docker build -t web .\web

Clear-Host
docker images

$containerID = docker run -d web
$containerID

Clear-Host
docker ps

docker exec $containerID powershell Get-ChildItem c:\inetpub\wwwroot

docker exec $containerID ipconfig